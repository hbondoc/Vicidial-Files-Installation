# HBTutorial Web Phone Setup Guide

## Quick Start

### 1. Upload Files
Upload all files to your Vicidial server in a subdirectory under the AGC directory:

```bash
# Typical installation path
/srv/www/htdocs/agc/hbtutorial/
```

### 2. Configure Vicidial

#### Update System Settings
1. Log into Vicidial Admin
2. Navigate to: **ADMIN → System Settings**
3. Find the **Webphone URL** setting
4. Update to: `/agc/hbtutorial/cyburphone.php`

#### Optional: Use HBTutorial Theme
Add the HBTutorial theme parameter to your webphone URL:
```
WEBPHONELAYOUT=hbtutorial
```

Full example with parameters:
```
/agc/hbtutorial/cyburphone.php?WEBPHONELAYOUT=hbtutorial
```

### 3. WebRTC Template Setup

Create or update your WebRTC phone template in Vicidial with these parameters:

```ini
type=friend
host=dynamic
encryption=yes
icesupport=yes
directmedia=no
transport=wss
dtlsenable=yes
dtlsverify=no
dtlscertfile=/PATH/TO/YOUR/SSL/CERT
dtlsprivatekey=/PATH/TO/YOUR/SSL/KEY
dtlssetup=actpass
rtcp_mux=yes
```

**Important Notes:**
- `rtcp_mux=yes` is CRITICAL for proper functionality
- SSL certificates are REQUIRED (HTTPS only)
- Update the certificate paths to match your server

### 4. Test Installation

1. Open the demo page: `https://your-server.com/agc/hbtutorial/demo.html`
2. Verify the HBTutorial branding appears correctly
3. Test the webphone through Vicidial agent interface

## Available Themes

### HBTutorial Theme - 2025 Modern Edition (Recommended) ✨
- **Glassmorphism UI** with frosted glass effects
- **Vibrant gradients** with blue and purple tones
- **Large touch targets** (70x42px dialpad buttons)
- **Smooth animations** with cubic-bezier easing
- **Modern aesthetics** with 24px rounded corners
- File: `css/hbtutorial.css`

### Default Theme
- Original blue gradient design
- Classic appearance
- File: `css/default.css`

### Thin Theme
- Compact layout option
- File: `css/thin.css`

## Color Reference

The 2025 Modern Edition uses this vibrant color palette:

| Color Name | Hex Code | Usage |
|------------|----------|-------|
| Primary Blue | #0066FF | Main gradient, buttons, accents |
| Deep Blue | #0044CC | Gradient endpoints, text |
| Purple | #764ba2 | Secondary gradient accent |
| Pink | #f093fb | Background gradient accent |
| Success Green | #28A745 | DTMF send button, success states |
| Glass White | rgba(255,255,255,0.15-0.95) | Transparent panels and buttons |

### Design Highlights
- **Main Container**: 280×480px with 24px rounded corners
- **Glass Panels**: `backdrop-filter: blur(10px)` for frosted effect
- **Buttons**: Glass effect with hover lift animation
- **Inputs**: High contrast white (0.95 opacity) with centered text
- **Shadows**: Multi-layered for depth (0 10px 40px)

## Customization

### Creating a Custom Theme

1. Copy `css/hbtutorial.css` to `css/yourtheme.css`
2. Modify colors and styles as needed
3. Use parameter: `WEBPHONELAYOUT=yourtheme`

### Logo Customization

Replace the logo file at:
```
images/hbtutorial_logo.svg  (SVG preferred)
images/hbtutorial_logo.png  (PNG fallback)
```

Recommended dimensions: 220px × 45px (2025 Modern Edition)

**Note**: The 2025 edition uses SVG with automatic fallback to PNG for better quality on high-DPI displays.

## Troubleshooting

### Webphone Won't Load
- Verify HTTPS is enabled on your server
- Check SSL certificate is valid
- Ensure WebRTC template has `rtcp_mux=yes`

### Logo Not Displaying
- Verify logo file exists: `images/hbtutorial_logo.png`
- Check file permissions (should be readable by web server)
- Clear browser cache

### Theme Not Applying
- Verify theme file exists in `css/` directory
- Check webphone URL includes correct WEBPHONELAYOUT parameter
- Clear browser cache

## Support

For issues or questions about HBTutorial Web Phone:
- Check the README.md for general information
- Review Vicidial documentation for WebRTC setup
- Verify all requirements are met (HTTPS, WebRTC template, etc.)

## Security Notes

- **HTTPS is REQUIRED** - Webphone will not load without encryption
- Update default passwords immediately after installation
- Restrict access to configuration files
- Keep WebRTC libraries up to date
- Monitor debug logs for security issues

## File Structure

```
hbtutorial/
├── css/
│   ├── hbtutorial.css       # 2025 Modern Edition (UPDATED)
│   ├── default.css          # Default theme
│   └── thin.css             # Thin theme
├── images/
│   ├── hbtutorial_logo.svg  # HBTutorial logo SVG
│   ├── hbtutorial_logo.png  # HBTutorial logo PNG fallback
│   └── wp_*.gif/png         # Control icons
├── js/
│   ├── vici_phone.js        # Main application
│   ├── translations.js      # Language support
│   └── sip-0.15.11.min.js   # SIP.js library
├── sounds/                  # DTMF tones
├── cyburphone.php           # Main entry point
├── vp_template.php          # HTML template
├── index.html               # Welcome page (UPDATED)
├── demo.html                # Theme demo (UPDATED)
├── README.md                # Documentation (UPDATED)
├── SETUP.md                 # This file
├── CHANGELOG.md             # Version history (NEW)
└── DESIGN_UPDATE.md         # Design documentation (NEW)
```

