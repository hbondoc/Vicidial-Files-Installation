<!DOCTYPE html>
<html lang="en">
<head>
    <title>Agent Validation Portal</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Poppins', -apple-system, BlinkMacSystemFont, sans-serif;
            min-height: 100vh;
            display: flex;
            background: #f8fafc;
            overflow-x: hidden;
        }
        
        /* Split Layout */
        .split-left {
            flex: 1;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%);
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 60px;
            position: relative;
            overflow: hidden;
        }
        
        .split-right {
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 40px;
            background: #ffffff;
        }
        
        /* Animated shapes on left side */
        .shape {
            position: absolute;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.1);
            animation: morph 15s ease-in-out infinite;
        }
        
        .shape-1 {
            width: 300px;
            height: 300px;
            top: -50px;
            left: -50px;
            animation-delay: 0s;
        }
        
        .shape-2 {
            width: 200px;
            height: 200px;
            bottom: 100px;
            right: -30px;
            animation-delay: 5s;
        }
        
        .shape-3 {
            width: 150px;
            height: 150px;
            bottom: -30px;
            left: 30%;
            animation-delay: 10s;
        }
        
        .shape-4 {
            width: 80px;
            height: 80px;
            top: 40%;
            right: 20%;
            animation-delay: 2s;
        }
        
        @keyframes morph {
            0%, 100% {
                border-radius: 60% 40% 30% 70% / 60% 30% 70% 40%;
                transform: rotate(0deg) scale(1);
            }
            50% {
                border-radius: 30% 60% 70% 40% / 50% 60% 30% 60%;
                transform: rotate(180deg) scale(1.1);
            }
        }
        
        /* Branding section */
        .branding {
            position: relative;
            z-index: 2;
            text-align: center;
            color: #ffffff;
        }
        
        .brand-logo {
            width: 120px;
            height: 120px;
            object-fit: contain;
            margin-bottom: 32px;
            filter: drop-shadow(0 10px 30px rgba(0, 0, 0, 0.2));
            animation: float 4s ease-in-out infinite;
        }
        
        @keyframes float {
            0%, 100% { transform: translateY(0) rotate(0deg); }
            50% { transform: translateY(-15px) rotate(2deg); }
        }
        
        .brand-title {
            font-size: 42px;
            font-weight: 700;
            margin-bottom: 16px;
            text-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
        }
        
        .brand-subtitle {
            font-size: 18px;
            font-weight: 300;
            opacity: 0.9;
            max-width: 300px;
            line-height: 1.6;
        }
        
        /* Features list */
        .features {
            margin-top: 48px;
            display: flex;
            flex-direction: column;
            gap: 16px;
        }
        
        .feature-item {
            display: flex;
            align-items: center;
            gap: 12px;
            font-size: 14px;
            opacity: 0.9;
        }
        
        .feature-icon {
            width: 24px;
            height: 24px;
            background: rgba(255, 255, 255, 0.2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 12px;
        }
        
        /* Login card */
        .login-container {
            width: 100%;
            max-width: 420px;
            animation: slideIn 0.6s ease-out;
        }
        
        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateX(30px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }
        
        .login-header {
            margin-bottom: 40px;
        }
        
        .login-title {
            font-size: 32px;
            font-weight: 700;
            color: #1e293b;
            margin-bottom: 8px;
        }
        
        .login-subtitle {
            color: #64748b;
            font-size: 15px;
        }
        
        /* Form styles */
        .login-form {
            display: flex;
            flex-direction: column;
            gap: 24px;
        }
        
        .input-group {
            position: relative;
        }
        
        .input-label {
            display: block;
            font-size: 13px;
            font-weight: 600;
            color: #475569;
            margin-bottom: 8px;
        }
        
        .input-wrapper {
            position: relative;
        }
        
        .input-icon {
            position: absolute;
            left: 16px;
            top: 50%;
            transform: translateY(-50%);
            color: #94a3b8;
            font-size: 18px;
            transition: color 0.3s ease;
        }
        
        .form-input {
            width: 100%;
            padding: 16px 16px 16px 50px;
            background: #f8fafc;
            border: 2px solid #e2e8f0;
            border-radius: 14px;
            font-size: 15px;
            font-family: inherit;
            color: #1e293b;
            transition: all 0.3s ease;
            outline: none;
        }
        
        .form-input::placeholder {
            color: #94a3b8;
        }
        
        .form-input:focus {
            background: #ffffff;
            border-color: #667eea;
            box-shadow: 0 0 0 4px rgba(102, 126, 234, 0.1);
        }
        
        .form-input:focus + .input-icon,
        .input-wrapper:hover .input-icon {
            color: #667eea;
        }
        
        /* Submit button */
        .submit-btn {
            width: 100%;
            padding: 18px 32px;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
            border-radius: 14px;
            color: #ffffff;
            font-size: 16px;
            font-weight: 600;
            font-family: inherit;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
            overflow: hidden;
            margin-top: 8px;
        }
        
        .submit-btn::after {
            content: '→';
            position: absolute;
            right: 24px;
            top: 50%;
            transform: translateY(-50%);
            opacity: 0;
            transition: all 0.3s ease;
        }
        
        .submit-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 20px 40px -10px rgba(102, 126, 234, 0.5);
            padding-right: 50px;
        }
        
        .submit-btn:hover::after {
            opacity: 1;
            right: 20px;
        }
        
        .submit-btn:active {
            transform: translateY(-1px);
        }
        
        /* Status messages */
        .alert {
            padding: 16px 20px;
            border-radius: 14px;
            margin-bottom: 24px;
            display: flex;
            align-items: center;
            gap: 12px;
            animation: shake 0.5s ease-out;
        }
        
        @keyframes shake {
            0%, 100% { transform: translateX(0); }
            20%, 60% { transform: translateX(-5px); }
            40%, 80% { transform: translateX(5px); }
        }
        
        .alert-error {
            background: linear-gradient(135deg, #fef2f2 0%, #fee2e2 100%);
            border: 1px solid #fecaca;
            color: #dc2626;
        }
        
        .alert-success {
            background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%);
            border: 1px solid #bbf7d0;
            color: #16a34a;
            animation: none;
        }
        
        .alert-warning {
            background: linear-gradient(135deg, #fffbeb 0%, #fef3c7 100%);
            border: 1px solid #fde68a;
            color: #d97706;
        }
        
        .alert-icon {
            font-size: 20px;
            flex-shrink: 0;
        }
        
        .alert-content {
            flex: 1;
        }
        
        .alert-title {
            font-weight: 600;
            font-size: 14px;
        }
        
        .alert-text {
            font-size: 13px;
            opacity: 0.8;
            margin-top: 2px;
        }
        
        /* IP Badge */
        .ip-display {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 8px 16px;
            background: #f1f5f9;
            border-radius: 8px;
            font-family: 'SF Mono', 'Fira Code', monospace;
            font-size: 13px;
            color: #475569;
            margin-top: 12px;
        }
        
        .ip-dot {
            width: 8px;
            height: 8px;
            background: #22c55e;
            border-radius: 50%;
            animation: blink 2s infinite;
        }
        
        @keyframes blink {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }
        
        /* Redirect card */
        .redirect-card {
            margin-top: 24px;
            padding: 24px;
            background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
            border-radius: 16px;
            text-align: center;
        }
        
        .countdown-ring {
            width: 70px;
            height: 70px;
            margin: 0 auto 16px;
            position: relative;
        }
        
        .countdown-ring svg {
            transform: rotate(-90deg);
        }
        
        .countdown-ring circle {
            fill: none;
            stroke-width: 4;
        }
        
        .countdown-ring .bg {
            stroke: #e2e8f0;
        }
        
        .countdown-ring .progress {
            stroke: url(#gradient);
            stroke-linecap: round;
            stroke-dasharray: 188;
            animation: countdown-progress linear forwards;
        }
        
        .countdown-number {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            font-size: 24px;
            font-weight: 700;
            color: #667eea;
        }
        
        .redirect-text {
            color: #64748b;
            font-size: 14px;
            line-height: 1.6;
        }
        
        .redirect-link {
            color: #667eea;
            font-weight: 600;
            text-decoration: none;
            transition: color 0.3s ease;
        }
        
        .redirect-link:hover {
            color: #764ba2;
        }
        
        .redirect-hint {
            margin-top: 12px;
            font-size: 12px;
            color: #94a3b8;
        }
        
        /* Footer */
        .footer {
            margin-top: 40px;
            text-align: center;
            color: #94a3b8;
            font-size: 13px;
        }
        
        .footer a {
            color: #667eea;
            text-decoration: none;
        }
        
        /* Responsive */
        @media (max-width: 1024px) {
            .split-left {
                display: none;
            }
            
            .split-right {
                flex: none;
                width: 100%;
                min-height: 100vh;
                background: linear-gradient(180deg, #667eea 0%, #764ba2 100%);
            }
            
            .login-container {
                background: #ffffff;
                padding: 40px 32px;
                border-radius: 24px;
                box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.25);
            }
        }
        
        @media (max-width: 480px) {
            .split-right {
                padding: 20px;
            }
            
            .login-container {
                padding: 32px 24px;
            }
            
            .login-title {
                font-size: 26px;
            }
            
            .form-input {
                padding: 14px 14px 14px 46px;
            }
            
            .submit-btn {
                padding: 16px 24px;
            }
        }
    </style>
</head>
<body>

<?php
# valid8.php - ViciBox dynamic firewall validation portal
# Modern Split-Screen Design

require_once 'inc/defaults.inc.php';
require_once 'inc/dbconnect.inc.php';
require_once 'inc/functions.inc.php';

// See if we are redirected from elsewhere and are secure
$loginstate = 0; // 0 = no attempt, 1 = failed, 2 = success
$remoteip = $_SERVER['REMOTE_ADDR'];

if (chkgetpost("login")) { 
    $loginstate = getpostvar("login"); 
}

// If we are submitted, then do stuff
if (chkgetpost('submit')) {
    debugoutput("   IP $remoteip validation check submit", 2);
    $login = getpostvar("$PORTAL_useridvar");
    $pass = getpostvar("$PORTAL_passwdvar");
    $usergroup = '';
    debugoutput("Login: $login", 2);
    debugoutput("Pass: $pass", 2);
    $today = date("Y-m-d H:i:s");

    if ($PORTAL_incurdelay > 0) {
        sleep($PORTAL_incurdelay);
    }

    if (validate_pw($login, $pass)) {
        $loginstate = 2;
        logvalidip($login, $remoteip, $usergroup);
        debugoutput("Login Successful $today - User $login, IP $remoteip");

        if ($PORTAL_submitlocal == 1) {
            debugoutput("  Adding $remoteip to dynamiclist IPSET", 2);
            $SHELL_cmd = '/usr/sbin/ipset add dynamiclist ' . $remoteip . ' 2>&1';
            shell_exec($SHELL_cmd);
        }
    } else {
        $loginstate = 1;
        debugoutput("Login Unsuccessful $today - User $login, IP $remoteip");
    }
}
?>

    <!-- Left Panel - Branding -->
    <div class="split-left">
        <div class="shape shape-1"></div>
        <div class="shape shape-2"></div>
        <div class="shape shape-3"></div>
        <div class="shape shape-4"></div>
        
        <div class="branding">
            <img src="images/vicibox.png" alt="ViciBox Logo" class="brand-logo">
            <h1 class="brand-title">ViciBox</h1>
            <p class="brand-subtitle">Secure agent validation portal for authorized personnel</p>
            
            <div class="features">
                <div class="feature-item">
                    <span class="feature-icon">&#10003;</span>
                    <span>Secure IP validation</span>
                </div>
                <div class="feature-item">
                    <span class="feature-icon">&#10003;</span>
                    <span>Dynamic firewall access</span>
                </div>
                <div class="feature-item">
                    <span class="feature-icon">&#10003;</span>
                    <span>Real-time authentication</span>
                </div>
            </div>
        </div>
    </div>

    <!-- Right Panel - Login Form -->
    <div class="split-right">
        <div class="login-container">
            <div class="login-header">
                <h2 class="login-title">Welcome Back</h2>
                <p class="login-subtitle">Enter your credentials to access the system</p>
            </div>

            <?php if (!checksecure()): ?>
            <div class="alert alert-warning">
                <span class="alert-icon">&#9888;</span>
                <div class="alert-content">
                    <div class="alert-title">Insecure Connection</div>
                    <div class="alert-text">Please use HTTPS for secure login</div>
                </div>
            </div>
            <?php endif; ?>

            <?php if ($loginstate == 1): ?>
            <div class="alert alert-error">
                <span class="alert-icon">&#10060;</span>
                <div class="alert-content">
                    <div class="alert-title">Authentication Failed</div>
                    <div class="alert-text">Please check your credentials and try again</div>
                </div>
            </div>
            <?php elseif ($loginstate == 2): ?>
            <div class="alert alert-success">
                <span class="alert-icon">&#10004;</span>
                <div class="alert-content">
                    <div class="alert-title">Login Successful!</div>
                    <div class="alert-text">Your IP has been validated</div>
                </div>
            </div>
            
            <div class="ip-display">
                <span class="ip-dot"></span>
                <span><?php echo htmlspecialchars($remoteip); ?></span>
            </div>
            
            <?php if ($PORTAL_redirecturl != 'X'): ?>
            <?php
                debugoutput("   Portal Redirect to $PORTAL_redirecturl in $PORTAL_redirectsecs", 2);
                list($phonelogin, $phonepass, $adminfield) = getphonelogin($login);

                if ($PORTAL_redirectlogin == 1) {
                    if (strtolower($adminfield) == 'admin') {
                        $PORTAL_redirecturl = $PORTAL_redirectadmin . '?login=' . $login . '&login_pass=' . $pass;
                    } else {
                        $PORTAL_redirecturl = $PORTAL_redirecturl . '?phone_login=' . $phonelogin . '&phone_pass=' . $phonepass . '&VD_login=' . $login . '&VD_pass=' . $pass;
                    }
                }
            ?>
            <div class="redirect-card">
                <div class="countdown-ring">
                    <svg width="70" height="70" viewBox="0 0 70 70">
                        <defs>
                            <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                                <stop offset="0%" stop-color="#667eea" />
                                <stop offset="100%" stop-color="#764ba2" />
                            </linearGradient>
                        </defs>
                        <circle class="bg" cx="35" cy="35" r="30" />
                        <circle class="progress" cx="35" cy="35" r="30" id="progress-circle" />
                    </svg>
                    <span class="countdown-number" id="countdown"><?php echo $PORTAL_redirectsecs; ?></span>
                </div>
                <p class="redirect-text">
                    Redirecting to <a href="<?php echo htmlspecialchars($PORTAL_redirecturl); ?>" class="redirect-link">Login Page</a>
                </p>
                <p class="redirect-hint">Bookmark the login page for easier access</p>
            </div>
            
            <script>
                (function() {
                    var totalSecs = <?php echo (int)$PORTAL_redirectsecs; ?>;
                    var timeInSecs = totalSecs - 1;
                    var redirectUrl = "<?php echo addslashes($PORTAL_redirecturl); ?>";
                    var circle = document.getElementById('progress-circle');
                    var circumference = 2 * Math.PI * 30;
                    
                    circle.style.strokeDasharray = circumference;
                    circle.style.strokeDashoffset = 0;
                    
                    var ticker = setInterval(function() {
                        if (timeInSecs > 0) {
                            document.getElementById("countdown").innerHTML = timeInSecs;
                            var progress = (totalSecs - timeInSecs) / totalSecs;
                            circle.style.strokeDashoffset = circumference * progress;
                            timeInSecs--;
                        } else {
                            clearInterval(ticker);
                            window.location.replace(redirectUrl);
                        }
                    }, 1000);
                })();
            </script>
            <?php endif; ?>
            
            <?php else: ?>
            <form action="valid85.php" method="post" class="login-form" autocomplete="off">
                <div class="input-group">
                    <label class="input-label" for="userid">User ID</label>
                    <div class="input-wrapper">
                        <input 
                            type="text" 
                            id="userid"
                            name="<?php echo htmlspecialchars($PORTAL_useridvar); ?>" 
                            class="form-input" 
                            placeholder="Enter your user ID"
                            required
                            autofocus
                        >
                        <span class="input-icon">&#128100;</span>
                    </div>
                </div>
                
                <div class="input-group">
                    <label class="input-label" for="password">Password</label>
                    <div class="input-wrapper">
                        <input 
                            type="password" 
                            id="password"
                            name="<?php echo htmlspecialchars($PORTAL_passwdvar); ?>" 
                            class="form-input" 
                            placeholder="Enter your password"
                            required
                        >
                        <span class="input-icon">&#128274;</span>
                    </div>
                </div>
                
                <button type="submit" name="submit" value="1" class="submit-btn">
                    Sign In
                </button>
            </form>
            <?php endif; ?>

            <div class="footer">
                <p>ViciBox Dynamic Portal &copy; <?php echo date('Y'); ?></p>
            </div>
        </div>
    </div>
</body>
</html>

